<template>
  <div id="app">
    <div id="nav">
      <router-link />
    </div>
    <router-view/>
    <div class="footer">
      <span>The more you ask, the better you grow!</span>
    </div>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#app .footer{
  bottom: 0;
  width: 100%;
  background-color: black;
  color: white;
  position: fixed;
}

</style>
