import axios from 'axios'

const url = 'api/posts/';

class PostService{
    static updateUserDetails(id,data){
        return axios.post(url+'register/'+id,data)
    }

    static getUserName(id)
    {
        return axios.get(url+'/getUserName/'+id)
    }

    static postQuestion(data){
        return axios.post(url+'postQuestion/',data)
    }

    static getAllPosts(){
        return axios.get(url+'getAllPosts/')
    }

    static deletePost(id){
        return axios.delete(url+'deletePost/'+id);
    }

    static getPostDetail(id){
        return axios.get(url+'getPostDetail/'+id)
    }

    static postComment(data){
        return axios.post(url+'postComment/',data)
    }

    static getAllComments(data){
        console.log(data)
        return axios.post(url+'getAllComments/',data)
    }

    static deleteTheComment(data){
        return axios.post(url+'deleteComment/',data)
    }

    static updateQuestion(data,id){
        return axios.put(url+'updateQuestion/'+id,data)
    }
}

export default PostService