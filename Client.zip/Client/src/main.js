import Vue from 'vue'
import App from './App.vue'
import router from './router'
import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'
import Vuelidate from 'vuelidate'
import firebase from 'firebase'
import store from './store'

Vue.config.productionTip = false

Vue.use(Vuelidate)

const firebaseConfig = {
  apiKey: "AIzaSyD8dYeP7_oWVrViK6YaBtNC_9AN73Chb6o",
  authDomain: "testapi-18006.firebaseapp.com",
  databaseURL: "https://testapi-18006.firebaseio.com",
  projectId: "testapi-18006",
  storageBucket: "testapi-18006.appspot.com",
  messagingSenderId: "590519993392",
  appId: "1:590519993392:web:c42aad57215cfed5f319f5"
};


firebase.initializeApp(firebaseConfig);

let app;

firebase.auth().onAuthStateChanged(user => {
  console.log("user", user);
  if (!app) {
    app = new Vue({
      router,
      store,
      render: h => h(App)
    }).$mount("#app");
  }
});
