<template>
    <div class="PostPage">
        <div class="topNav">
            <div class="leftPane">
                <span>SHARE YOUR THOUGHTS!</span>
            </div>
            <div class="rightPane">
                <a href="" @click="goToQuestionPage">Ask Questions</a>
                <a href="" @click="goToMainPage">Back</a>
                <!-- <a href="">Profile</a> -->
                <a  href="" @click="signOut">Sign Out</a>
            </div>
        </div>
        <div class="PostsSection" v-if="!showUpdateFlag">
            <div class="question jumbotron"
            >
                <div class="usernameTimeArea">
                    <div class="userName">
                        <b>USERNAME: </b><span>{{postDetail.data.username}}</span>
                    </div>
                    <div class="postedTime">
                        <b>POSTED TIME: </b><span>{{postDetail.data.createdAt}}</span>
                    </div>
                </div>
                <div class="QuestionArea">
                    <div class="titleSection">
                        <span>{{postDetail.data.questionTitle}}</span>
                    </div>
                    <div class="tags">
                        <b>Tags:</b><span>{{postDetail.data.tagName}}</span>
                    </div>
                    <b><label>Description</label></b>
                    <div class="descSection jumbotron">
                        <span>{{postDetail.data.description}}</span>
                    </div>
                </div>
                <button v-if="postDetail.data.userid==id" class="btn btn-primary" @click="toggleFlag">Update</button>
            </div>
            <form @submit.prevent="postComment">
                <div class="postCommentArea">
                    <div class="titleArea">
                        <span>Post Your Comment:</span>
                    </div>
                    <div class="commentBox">
                        <textarea v-model="comment" placeholder="Type a comment..."></textarea>
                    </div>
                    <div class="submitArea">
                        <button @click="clearComment" class="btn btn-warning">Clear</button>
                        <button @click="postTheComment" class="btn btn-primary">Share</button>
                    </div>
                </div>
            </form>
            <div class="CommentsTitle">
                <span>All Comments</span>
            </div>
            <div class="allCommentsSection">
                <div class="comment"
                v-for="(post,index) in allComments.data"
                v-bind:item="post"
                v-bind:index="index"
                v-bind:key="post.id"
                >
                    <div class="userNameTime">
                        <div class="userName">
                            <span>{{post.username}}</span>
                        </div>
                        <div class="postedTime">
                            <span>{{post.createdAt}}</span>
                        </div>
                    </div>
                    <div class="jumbotron">
                        <span>{{post.comment}}</span>
                    </div>
                    <div class="deleteButton">
                        <button v-if="post.userid==id" @click="deleteComment(post.id)" class="btn btn-danger">Delete</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- Update Post -->
        <div class="QuestionSection" v-if="showUpdateFlag">
            <div class="titleArea">
                <h1>Share your Question</h1>
            </div>
            <form @submit.prevent="submitForm">
                <div class="QuestionFields formContent">
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="title">Question Title:</label>
                        </div>
                        <div class="inputSection">
                            <input type="text" v-model="title" id="title" placeholder="Enter your question title"
                            autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="description">Question Description:</label>
                        </div>
                        <div class="inputSection">
                            <textarea type="text" v-model="description" id="description" placeholder="Enter your question description"
                            autocomplete="off"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="tagName">Question Tags:</label>
                        </div>
                        <div class="inputSection">
                            <input type="text" v-model="tagName" id="tagName" placeholder="Type a tag and hit enter"
                            autocomplete="off" v-on:keydown.enter.prevent='addTag' >
                            <!-- <a href="#" @click="addTag" >Add</a> -->
                        </div>
                    </div>
                    <div class="allTags">
                            <div class="tagSection"
                            v-for="(post,index) in allTags"
                            v-bind:item="post"
                            v-bind:index="index"
                            v-bind:key="post.id"
                            >
                                <button @click="deleteTag(post)">{{post}} X</button>
                            </div>
                        </div>
                    <div class="form-group  submitSection">
                        <button class="btn btn-primary" type="submit">Update</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</template>

<script>
import firebase from 'firebase';
import "firebase/auth";
import PostService from '../PostService'
export default {
    name:"IndividualPost",
    data(){
        return{
            postId:'',
            postDetail :[],
            id:'',
            username:'',
            comment:'',
            allComments:[],
            showUpdateFlag:false,
            title:'',
            description:'',
            tagName:''
        }
    },
    mounted() {
        this.getPostId()
        this.getSecrets()
        // this.getAllComment()
    },
    created() {
      
  },
    methods: {
        async getPostId(){
            this.postId = localStorage.getItem("postId")
            this.postDetail = await PostService.getPostDetail(this.postId)
            firebase.firestore().collection('AllComments').doc(this.postId).collection("comments").orderBy('createdAt','desc').onSnapshot(this.getAllComment);
        },
        async getSecrets(){
            await firebase.auth().onAuthStateChanged(user => {
                this.id = user.uid;
            });
            this.response=await PostService.getUserName(this.id);
            this.username = this.response.data.username
        },
        signOut() {
            firebase
                .auth()
                .signOut()
                .then(() => {
                this.$router.replace({ name: "login" });
                });
        },
        goToQuestionPage(){
            this.$router.replace({name:"QuestionsPage"})
        },
        clearComment(){
            this.comment=""
        },
        async postTheComment(){
            var data = {
                "postId":this.postId,
                "username":this.username,
                "userid":this.id,
                "comment":this.comment,
                "createdAt": new Date(),
            }
            this.comment =""
            
            await PostService.postComment(data)
            this.getAllComment()
        },
        async getAllComment(){
            var data={"postId":this.postId}
            this.allComments = await PostService.getAllComments(data);
        },
        async deleteComment(id){
            var data={
                "id":id,
                "postId":this.postId
            }
            await PostService.deleteTheComment(data);
            this.getAllComment()
        },
        goToMainPage(){
            localStorage.removeItem("postId")
            this.$router.replace({name:'main'})
        },
        toggleFlag(){
            this.showUpdateFlag=true
            this.title = this.postDetail.data.questionTitle
            this.description = this.postDetail.data.description
            this.tagName = this.postDetail.data.tagName
        },
        async submitForm(){
            var data = {
                "userid":this.id,
                "username":this.username,
                "questionTitle":this.title,
                "description":this.description,
                "tagName":this.tagName,
                "createdAt": new Date(),
            }
            await PostService.updateQuestion(data,this.postId);
            alert('Updated Successfully')
            this.showUpdateFlag = false
            this.$router.replace({name:'main'})
        },
    },
}
</script>

<style scoped>

    .PostPage .topNav{
        display: grid;
        grid-template-columns: 50% 50%;
        background-color: black;
        color: white;
        padding: 2em 0em;
        position: sticky;
        top: 0;
    }

    .PostPage .topNav .leftPane{
        font-size:xx-large;
    }
    .PostPage .topNav .rightPane{
        display: flex;
        padding: 0.5em 3em;
    }

    .PostPage .topNav .rightPane a{
        text-decoration: none;
        padding: 0em 1em;
    }

    .PostsSection{
        padding:3em 10em;
    }

    .PostsSection .question, .allCommentsSection .comment{
        margin:0.5em 0em;
        text-align: left;
    
    }

    .allCommentsSection .comment{
        margin:1em 0em 3em 0em;
    }

    .PostsSection .question .usernameTimeArea, .allCommentsSection .comment .userNameTime{
        display:grid;
        grid-template-columns: 50% 50%;
    }

    .jumbotron{
        margin: 0.5em 0em;
        padding: 1em 2em;
    }

    .PostsSection .question button{
        text-align: right;
    }

    .PostsSection .question .QuestionArea .titleSection{
        font-size: xx-large;
        padding: 1em 0em;
        font-weight: bold;
    }

    .PostsSection .question .QuestionArea .tags{
        padding: 1em 0em;
    }
    .PostsSection .question .QuestionArea .descSection{
        color: black;
        margin: 0.5em 0em;
        font-family: initial;
    }

    .PostsSection .question label{
        margin-right: 1em;
    }

    .PostsSection .question .deleteCommentPost{
        text-align: right;
    }

    .PostsSection .question .deleteCommentPost button{
        margin:0em 0.5em;
    }

    .PostsSection .postCommentArea{
        text-align: left;
        padding: 1em 0em;
    }

    .PostsSection .postCommentArea .titleArea{
        font-size: x-large;
    }

    .PostsSection .postCommentArea .commentBox textarea{
        width: 100%;
    }

    .PostsSection .postCommentArea .submitArea, .allCommentsSection .deleteButton{
        text-align: right;
    }

    .PostsSection .postCommentArea .submitArea button{
        margin:0em 1em;
    }

    .CommentsTitle
    {
        text-align:left;
        padding: 1em 0em;
        font-size: x-large;
        text-decoration: underline;
    }


    .QuestionSection{
        padding: 3em;
    }


    .QuestionSection .formContent{
        padding: 0em 10em;
        width: 100%;
    }
    .QuestionSection .form-group{
        display: grid;
        grid-template-columns: 20% 80%;
    }

    .QuestionSection .form-group > *{
        margin: 0.5em;
    }
    .QuestionSection input,.QuestionSection textarea{
        width: 100%;
        height: 2.5em;
    }

    .QuestionSection textarea{
        height: 7em;
    }

    .QuestionSection .labelSection{
        text-align: right;
    }
    .QuestionSection .form-group >button{
        width: 10em;
    }
    .QuestionSection .submitSection{
        float: right;
    }

    .QuestionSection .allTags{
        display: flex;
        flex-wrap: wrap;
        width: 100%;
    }

    .QuestionSection .allTags button{
        margin:0.5em 1em;
        width: fit-content;
    }


@media only screen and (min-width : 320px) and (max-width : 600px){
    .PostPage .topNav{
        display: block;
        top: -7.3em;
    }
    .PostPage .topNav .rightPane{
        display: unset;
        padding: 0;
        text-align: center;
    }
    .PostsSection{
        padding:3em 0.5em;
    }
    .PostsSection .question .usernameTimeArea, .allCommentsSection .comment .userNameTime {
        display: block;
    }
    .PostsSection .question .QuestionArea .titleSection {
        font-size: x-large;
        word-wrap: break-word;
    }
    .PostsSection .question .QuestionArea .descSection {
        padding: 1em 0.5em;
        word-wrap: break-word;
    }
    .QuestionSection {
        padding: 3em 0.5em;
    }
    .QuestionSection .formContent{
        padding: 0em 0.5em;
    }
    .QuestionSection .form-group{
        display: block;
    }
    .QuestionSection .labelSection{
        text-align: center;
    }
    .QuestionSection .submitSection{
        float: none;
    }

}

@media only screen and (min-width : 600px) and (max-width : 1024px){
    .PostPage .topNav .rightPane{
        padding: 0.5em 2em;
    }
}


</style>