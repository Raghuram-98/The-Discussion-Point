import Vue from 'vue'
import VueRouter from 'vue-router'
// import Login from '../views/login.vue'
import SignUp from '../views/SignUp.vue'
import Main from '../views/Main.vue'
import * as firebase from "firebase/app";
import QuestionsPage from "../views/QuestionsPage.vue"
import IndividualPostPage from "../views/IndividualPost.vue"
import profilePage from "../views/profilePage.vue"
import "firebase/auth";

Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'login',
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/login.vue")
  },
  {
      path:'/signup',
      name:'signup',
      component:SignUp
  },
  {
      path:'/main',
      name:'main',
      component:Main,
      meta: { requiresAuth: true , reload:true}
  },
  {
    path:'/askQuestion',
    name:'QuestionsPage',
    component:QuestionsPage,
    meta: { requiresAuth: true }
  },
  {
    path:'/postPage',
    name:'IndividualPostPage',
    component:IndividualPostPage,
    meta: { requiresAuth: true }
  },
  {
    path:'/profilePage',
    name:'profilePage',
    component:profilePage,
    meta: { requiresAuth: true }
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
    to.matched.some(record=>console.log(record))
    const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
    var isAuthenticated = firebase.auth().currentUser;
    if (requiresAuth && !isAuthenticated) {
      next("/");
    } 
    else {
      next();
    }
  });
  

export default router
