<template>
    <div class="mainPage">
        <div class="topNav">
            <div class="leftPane">
                <span>THE DISCUSSION POINT</span>
            </div>
            <div class="rightPane">
                <a href="" @click="goToQuestionPage">Ask Questions</a>
                <a href="" @click="gotoProfile">Profile</a>
                <a  href="" @click="signOut">Sign Out</a>
            </div>
        </div>
        <div class="searchPost">
          <label for="search">Search Based on Title or Tags:</label>
          <input type="text" id="search" v-model="search" v-on:keyup="filteredList" placeholder="Seek what you want">
        </div>
        <div class="allPostsSection">
            <div class="question jumbotron"
            v-for="(post,index) in filteredList.slice(0,messageCount)"
            v-bind:item="post"
            v-bind:index="index"
            v-bind:key="post.id"
            >
                <div class="usernameTimeArea">
                    <div class="userName">
                        <b>USERNAME:</b><span>{{post.username}}</span>
                    </div>
                    <div class="postedTime">
                       <b>POSTED TIME:</b> <span>{{post.createdAt}}</span>
                    </div>
                </div>
                <div class="QuestionArea">
                    <div class="titleSection">
                        <span>{{post.questionTitle}}</span>
                    </div>
                    <div class="tags">
                        <b><label>Tags:</label></b><span>{{post.tagName}}</span>
                    </div>
                    <b><label>Description</label></b>
                    <div class="descSection jumbotron">
                        <span>{{post.description}}</span>
                    </div>
                </div>
                <div class="deleteCommentPost">
                    <button class="btn btn-primary" @click="gotoIndividualPost(post.id)">Your Thoughts?</button>
                    <button class="btn btn-danger"  v-if="post.userid ==id" @click="deletePost(post.id)">Delete Post</button>
                </div>

            </div>
            <div class="loadMore" v-if="showLoadMore">
                <a v-on:click="loadMessages">Load More>>></a>
            </div>
        </div>
    </div>
</template>

<script>
import firebase from 'firebase';
import "firebase/auth";
import PostService from '../PostService'
export default {
    data(){
        return{
            id:'',
            allPosts:[],
            search:'',
            messageCount : 5,
            showLoadMore:true,
            authToken:''
        }
    },
    computed:{
    filteredList() {
      if(this.search == '')
      {
        return this.allPosts.data
      }
      else
      {
        return this.allPosts.data.filter(post => {
            return (post.tagName.toLowerCase().includes(this.search.toLowerCase()) || post.questionTitle.toLowerCase().includes(this.search.toLowerCase()))
        }) 
      }
    },
  },
  async created() {
      await firebase.auth().currentUser.getIdToken(true)
        .then((idToken) => {
            this.authToken=idToken
    }).catch((error) => {
            console.log("Error getting auth token",error)
        });
      firebase.firestore().collection('Questions').orderBy('createdAt','desc').onSnapshot(this.getAllPosts);
  },
    mounted() {
        this.getSecrets()
        this.getAllPosts()
    },
    methods: {
        async signOut() {
            await firebase
                .auth()
                .signOut()
                .then(() => {
                this.$router.replace({ name: "login" });
                });
        },
        async getSecrets(){
            await firebase.auth().onAuthStateChanged(user => {
                this.id = user.uid;
            });
        },
        goToQuestionPage(){
            this.$router.replace({name:"QuestionsPage"})
        },
        async getAllPosts(){
            this.allPosts = await PostService.getAllPosts(this.authToken);
        },
        async deletePost(id){
            await PostService.deletePost(id,this.authToken);
            this.getAllPosts()
        },
        async gotoIndividualPost(id){
            localStorage.setItem("postId",id);
            this.$router.replace({name:"IndividualPostPage"})
        },
        async gotoProfile(){
            this.$router.replace({name:"profilePage"})
        },
        loadMessages(){
            this.messageCount = this.messageCount +20
            if(this.messageCount > this.allPosts.data.length){
                this.showLoadMore=false
            }
        },
    },
}
</script>

<style scoped>

    .mainPage .topNav{
        display: grid;
        grid-template-columns: 50% 50%;
        background-color: black;
        color: white;
        padding: 2em 0em;
        position: sticky;
        top: 0;
    }

    .mainPage .topNav .leftPane{
        font-size:xx-large;
    }
    .mainPage .topNav .rightPane{
        display: flex;
        padding: 0.5em 3em;
    }

    .mainPage .topNav .rightPane a{
        text-decoration: none;
        padding: 0em 1em;
    }


    .searchPost{
        padding: 2em 10em 0em 10em;
        width:100%;
    }
    .searchPost label{
        font-size: x-large;
    }

    .searchPost input{
        width: 100%;
    }

    .allPostsSection{
        padding:3em 10em;
    }

    .allPostsSection .question{
        margin:0.5em 0em;
        text-align: left;
    }

    .allPostsSection .question:hover{
        border: 1px solid black;
        cursor: pointer;
    }

    .allPostsSection .question .titleSection{
        font-size: xx-large;
        padding: 1em 0em;
        font-weight: bold;
    }

    .allPostsSection .question .usernameTimeArea{
        display:grid;
        grid-template-columns: 50% 50%;
    }

    .jumbotron{
        margin: 0;
        padding: 1em 2em;
    }

    .allPostsSection .question .QuestionArea .descSection{
        color: black;
        margin: 0.5em 0em;
        font-family: initial;
        font-size: large;
    }

    .allPostsSection .question label{
        margin-right: 1em;
    }

    .allPostsSection .question .deleteCommentPost{
        text-align: right;
    }

    .allPostsSection .question .deleteCommentPost button{
        margin: 0.5em 0.5em;
    }

    .allPostsSection .loadMore a:hover{
        cursor: pointer;
        text-decoration: underline;
    }


@media only screen and (min-width : 320px) and (max-width : 600px){
    .mainPage .topNav{
        display: block;
        top: -7.3em;
    }

    .mainPage .topNav .rightPane{
        text-align: center;
        font-size: 14px;
        display: unset;
        padding: 0.5em 0em;
    }

    .searchPost {
        padding: 1em 0.5em;
        width: 100%;
    }

    .allPostsSection {
        padding: 3em 0.5em;
    }

    .allPostsSection .question .usernameTimeArea {
        display: block;
    }


    .allPostsSection .question .titleSection{
        font-size: x-large;
        word-break: break-word;
    }

    .allPostsSection .question .QuestionArea .descSection {
        padding: 0em;
        word-break: break-word;
    }

}


@media only screen and (min-width : 600px) and (max-width : 1024px){
    .mainPage .topNav .rightPane{
        display: flex;
        padding: 0.5em 2em;
    }
}

</style>