<template>
    <div class="loginSection">
        <div class="titleSection">
            <h1>Welcome to Discussion Centre</h1>
        </div>
        <form @submit.prevent="submitForm">
            <div class="formContent">
                <div class="form-group">
                    <div class="labelSection">
                        <label for="email">Email:</label>
                    </div>
                    <div class="inputSection">
                        <input type="text" v-model="email" id="email" class="fadeIn second" placeholder="Email" 
                                v-model.trim="$v.email.$model" :class="{
                                            'is-invalid': $v.email.$error, 'is-valid': !$v.email.$invalid
                                        }"
                        autocomplete="off" >
                        <div class="valid-feedback">
                            Your email is valid!
                        </div>
                        <div class="invalid-feedback">
                            <span v-if="!$v.email.required">Email is required.</span>
                            <span v-if="!$v.email.isUnique">Email is invalid.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="labelSection">
                        <label for="password">Password:</label>
                    </div>
                    <div class="inputSection">
                        <input type="password" id="password" ref="password" placeholder="Set a password"
                        v-model.trim="$v.password.$model" :class="{
                                            'is-invalid': $v.password.$error, 'is-valid': !$v.password.$invalid
                                        }"
                        >
                        <div class="valid-feedback">
                            Your password is valid!
                        </div>
                        <div class="invalid-feedback">
                            <span v-if="!$v.password.required">Password is required.</span>
                            <span v-if="!$v.password.minLength">{{$v.password.$params.minLength.min}} characters minimum.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group  submitSection">
                    <button class="btn btn-primary" type="submit">Login</button>
                    <button class="btn btn-primary" v-on:click="goToSignUpPage">Sign Up</button>
                </div>
            </div>
        </form>
       
    </div>
</template>

<script>
import {email, required, minLength} from 'vuelidate/lib/validators'
import firebase from 'firebase'
import 'firebase/auth'
// import PostService from '../PostService'

export default {
    name:"login",
    data(){
        return{
            email:'',
            password:'',
            error:'',
        }
    },
    validations: {
        email:{
            required,
            email,
            isUnique (value){
                if(value==='') return true

                //eslint-disable-next-line
                var email_regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

                return new Promise((resolve)=>{
                    setTimeout(()=>{
                        resolve(email_regex.test(value))
                    }, 350+Math.random()*300)
                })
            },
        },
        password:{
            required,
            minLength: minLength(8),
        },
    },  
    methods: {
        goToSignUpPage(){
            this.$router.replace({name:'signup'})
        },
        async submitForm(){
            if(this.$v.$invalid)
            {
                alert('Login Failed!')
            }
            else
            {
                await firebase.auth().signInWithEmailAndPassword(this.email,this.password)
                .then(data =>{
                    console.log(data)
                    alert('Login Success!')
                    this.$router.replace({name:'main'})
                }).catch((error)=>{this.error=error,alert('Invalid Credentials!')})
                
            }
        }
    },
}
</script>

<style scoped>

    .titleSection{
        background-color: black;
        color: white;
        padding:1em;
    }

    .formContent{
        width:50%;
        margin:5% 15%;
    }
    .form-group{
        display: grid;
        grid-template-columns: 50% 50%;
    }

    .form-group > *{
        margin: 0.5em;
    }

    .labelSection{
        text-align: right;
    }
    .form-group >button{
        width: 10em;
    }
    .submitSection{
        float: right;
    }



@media only screen and (min-width : 320px) and (max-width : 600px){
    .formContent{
        width:100%;
        margin:0;
    }

    .form-group{
        display: block;
    }

    .labelSection{
        text-align: center;
    }
    .submitSection{
        float: none;
    }
}
</style>