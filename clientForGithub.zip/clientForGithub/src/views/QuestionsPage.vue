<template>
    <div class="QuestionPage">
        <div class="topNav">
            <div class="leftPane">
                <span>SHOOT YOUR QUESTIONS HERE</span>
            </div>
            <div class="rightPane">
                <a href="" @click="goToMainPage">Back</a>
                <a href="" @click="gotoProfile">Profile</a>
                <a  href="" @click="signOut">Sign Out</a>
            </div>
        </div>
        <div class="QuestionSection">
            <div class="titleArea">
                <h1>Share your Question</h1>
            </div>
            <form @submit.prevent="submitForm">
                <div class="QuestionFields formContent">
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="title">Question Title:</label>
                        </div>
                        <div class="inputSection">
                            <input type="text" v-model="title" id="title" placeholder="Enter your question title"
                            autocomplete="off" v-model.trim="$v.title.$model" :class="{
                                            'is-invalid': $v.title.$error, 'is-valid': !$v.title.$invalid
                                        }">
                            <div class="valid-feedback">
                                Title is valid!
                            </div>
                            <div class="invalid-feedback">
                                <span v-if="!$v.title.required">Title is required.</span>
                                <span v-if="!$v.title.minLength">{{$v.title.$params.minLength.min}} characters minimum.</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="description">Question Description:</label>
                        </div>
                        <div class="inputSection">
                            <textarea type="text" v-model="description" id="description" placeholder="Enter your question description"
                            autocomplete="off"  v-model.trim="$v.description.$model" :class="{
                                            'is-invalid': $v.description.$error, 'is-valid': !$v.description.$invalid
                                        }"></textarea>
                            <div class="valid-feedback">
                                Description is valid!
                            </div>
                            <div class="invalid-feedback">
                                <span v-if="!$v.description.required">Description is required.</span>
                                <span v-if="!$v.description.minLength">{{$v.description.$params.minLength.min}} characters minimum.</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="labelSection">
                            <label for="tagName">Question Tags:</label>
                        </div>
                        <div class="inputSection">
                            <input type="text" v-model="tagName" id="tagName" placeholder="Type a tag and hit enter"
                            autocomplete="off" v-on:keydown.enter.prevent='addTag' >
                            <!-- <a href="#" @click="addTag" >Add</a> -->
                        </div>
                    </div>
                    <div class="allTags">
                            <div class="tagSection"
                            v-for="(post,index) in allTags"
                            v-bind:item="post"
                            v-bind:index="index"
                            v-bind:key="post.id"
                            >
                                <button @click="deleteTag(post)">{{post}} X</button>
                            </div>
                        </div>
                    <div class="form-group  submitSection">
                        <button class="btn btn-primary" type="submit">Post</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
import { required, minLength} from 'vuelidate/lib/validators'
import firebase from 'firebase'
import 'firebase/auth'
import PostService from '../PostService'
export default {
    name:"QuestionsPage",
    data(){
        return{
            title:'',
            tagName:'',
            description:'',
            id:'',
            response : [],
            username:'',
            allTags:[],
            authToken:''
        }
    },
    async mounted() {
        await firebase.auth().currentUser.getIdToken(true)
        .then((idToken) => {
                this.authToken=idToken
        }).catch((error) => {
            console.log("Error getting auth token",error)
        });
        this.getSecrets()
    },
    validations: {
        title:{
            required,
            minLength: minLength(10),
        },
        description:{
            required,
            minLength: minLength(25),
        }
    },  
    methods: {
        async signOut() {
            await firebase
                .auth()
                .signOut()
                .then(() => {
                this.$router.replace({ name: "login" });
                });
        },
        async submitForm(){
            if(this.$v.$invalid)
            {
                alert('Failed to post!')
            }
            else
            {
                var tagNames = ""
                for(var i=0;i<this.allTags.length;i++)
                {
                    if(i!=0)
                    {
                        tagNames = tagNames + ","
                    }
                    tagNames = tagNames + this.allTags[i]
                }
                var data = {
                    "userid":this.id,
                    "username":this.username,
                    "questionTitle":this.title,
                    "description":this.description,
                    "tagName":tagNames,
                    "createdAt": new Date(),
                }
                await PostService.postQuestion(data,this.authToken);
                alert('Posted Successfully')
                this.$router.replace({name:'main'})
            }
        },
        async getSecrets(){
            await firebase.auth().onAuthStateChanged(user => {
                this.id = user.uid;
            });
            this.response=await PostService.getUserName(this.id,this.authToken);
            this.username = this.response.data.username
        },
        goToMainPage(){
            this.$router.replace({name:'main'})
        },
        async addTag(){
            this.allTags.push(this.tagName)
            this.tagName=""
        },
        deleteTag(post){
            this.allTags.splice(this.allTags.indexOf(post),1)
        },
        async gotoProfile(){
            this.$router.replace({name:"profilePage"})
        }
    },
}
</script>

<style scoped>
    .QuestionPage .topNav{
        display: grid;
        grid-template-columns: 50% 50%;
        background-color: black;
        color: white;
        padding: 2em 0em;
        position: sticky;
        top: 0;
    }

    .QuestionPage .topNav .leftPane{
        font-size:xx-large;
    }
    .QuestionPage .topNav .rightPane{
        display: flex;
        padding: 0.5em 3em;
    }

    .QuestionPage .topNav .rightPane a{
        text-decoration: none;
        padding: 0em 1em;
    }

    .QuestionSection{
        padding: 3em;
    }


    .formContent{
        padding: 0em 10em;
        width: 100%;
    }
    .form-group{
        display: grid;
        grid-template-columns: 20% 80%;
    }

    .form-group > *{
        margin: 0.5em;
    }
    input, textarea{
        width: 100%;
        height: 2.5em;
    }

    textarea{
        height: 7em;
    }

    .labelSection{
        text-align: right;
    }
    .form-group >button{
        width: 10em;
    }
    .submitSection{
        float: right;
    }

    .allTags{
        display: flex;
        flex-wrap: wrap;
        width: 100%;
    }

    .allTags button{
        margin:0.5em 1em;
        width: fit-content;
    }

@media only screen and (min-width : 320px) and (max-width : 600px){
    .QuestionPage .topNav{
        display: block;
        top: -7.3em;
    }

    .QuestionPage .topNav .rightPane{
        display: unset;
        padding: 0;
        text-align: center;
    }

    .QuestionSection {
        padding: 3em 0.5em;
    }

    .formContent {
        padding: 0em 0.5em;
    }

    .form-group{
        display:block;
    }

    .labelSection{
        text-align: center;
    }

    .submitSection{
        float: none;
    }

}

@media only screen and (min-width : 600px) and (max-width : 1024px){
    .QuestionPage .topNav .leftPane {
        padding: 0em 0.5em;
    }
    .formContent {
        padding: 0em 5em;
        width: 100%;
    }
}

</style>