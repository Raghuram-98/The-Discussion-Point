import axios from 'axios'

const url = 'api/posts/';

class PostService{
    static updateUserDetails(id,data,authToken){
        return axios.post(url+'register/'+id,data,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static getUserName(id,authToken){
        return axios.get(url+'/getUserName/'+id,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static postQuestion(data,authToken){
        return axios.post(url+'postQuestion/',data,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static getAllPosts(authToken){
        return axios.get(url+'getAllPosts/',{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static deletePost(id,authToken){
        return axios.delete(url+'deletePost/'+id,{
            headers: {
              'authtoken': authToken
            }
          });
    }

    static getPostDetail(id,authToken){
        return axios.get(url+'getPostDetail/'+id,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static postComment(data,authToken){
        return axios.post(url+'postComment/',data,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static getAllComments(data,authToken){
        console.log(data)
        return axios.post(url+'getAllComments/',data,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static deleteTheComment(data,authToken){
        return axios.post(url+'deleteComment/',data,{
            headers: {
              'authtoken': authToken
            }
          })
    }

    static updateQuestion(data,id,authToken){
        return axios.put(url+'updateQuestion/'+id,data,{
            headers: {
              'authtoken': authToken
            }
          })
    }
}

export default PostService